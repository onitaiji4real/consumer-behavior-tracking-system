<?php

return [
    'index' => 'Index Reports',
];
