<?php

return [
    'reports' => 'Reports',
];
