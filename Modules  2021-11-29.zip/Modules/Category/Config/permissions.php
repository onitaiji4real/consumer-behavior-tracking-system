<?php

return [
    'admin.categories' => [
        'index' => 'category::permissions.index',
        'create' => 'category::permissions.create',
        'edit' => 'category::permissions.edit',
        'destroy' => 'category::permissions.destroy',
    ],
];
