<?php

return [
    'admin.media' => [
        'index' => 'media::permissions.index',
        'create' => 'media::permissions.create',
        'destroy' => 'media::permissions.destroy',
    ],
];
