<?php

return [
    'index' => 'Index Media',
    'create' => 'Create Media',
    'destroy' => 'Delete Media',
];
