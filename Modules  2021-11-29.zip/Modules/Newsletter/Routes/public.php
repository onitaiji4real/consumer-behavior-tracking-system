<?php

use Illuminate\Support\Facades\Route;

Route::post('subscribers', 'SubscriberController@store')->name('subscribers.store');
