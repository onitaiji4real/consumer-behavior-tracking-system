<?php

return [
    'email' => 'Email',
];
