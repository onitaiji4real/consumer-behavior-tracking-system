<?php

return [
    'index' => 'Index Currency Rates',
    'edit' => 'Edit Currency Rates',
];
