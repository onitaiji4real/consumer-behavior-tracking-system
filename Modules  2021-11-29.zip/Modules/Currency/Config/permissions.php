<?php

return [
    'admin.currency_rates' => [
        'index' => 'currency::permissions.index',
        'edit' => 'currency::permissions.edit',
    ],
];
