<?php

return [
    'admin.tags' => [
        'index' => 'tag::permissions.index',
        'create' => 'tag::permissions.create',
        'edit' => 'tag::permissions.edit',
        'destroy' => 'tag::permissions.destroy',
    ],
];
