<?php

return [
    'tag' => 'Tag',
    'tags' => 'Tags',
    'table' => [
        'name' => 'Name',
    ],
    'tabs' => [
        'group' => [
            'tag_information' => 'Tag Information',
        ],
        'general' => 'General',
    ],
];
