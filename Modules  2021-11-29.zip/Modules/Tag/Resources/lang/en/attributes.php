<?php

return [
    'name' => 'Name',
    'slug' => 'URL',
];
