<?php

return [
    'index' => 'Index Tag',
    'create' => 'Create Tag',
    'edit' => 'Edit Tag',
    'destroy' => 'Delete Tag',
];
