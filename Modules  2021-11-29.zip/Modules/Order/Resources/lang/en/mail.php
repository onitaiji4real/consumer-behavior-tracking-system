<?php

return [
    'your_order_status_changed_subject' => 'Your order status is changed',
    'your_order_status_changed_text' => 'Your order #:order_id status is changed to :status.',
];
