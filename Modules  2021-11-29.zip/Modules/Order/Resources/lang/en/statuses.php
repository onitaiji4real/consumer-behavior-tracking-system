<?php

return [
    'canceled' => 'Canceled',
    'completed' => 'Completed',
    'on_hold' => 'On Hold',
    'pending' => 'Pending',
    'pending_payment' => 'Pending Payment',
    'processing' => 'Processing',
    'refunded' => 'Refunded',
];
