<?php

return [
    'users' => [
        'index' => 'Index Users',
        'create' => 'Create Users',
        'edit' => 'Edit Users',
        'destroy' => 'Delete Users',
    ],
    'roles' => [
        'index' => 'Index Roles',
        'create' => 'Create Roles',
        'edit' => 'Edit Roles',
        'destroy' => 'Delete Roles',
    ],
];
