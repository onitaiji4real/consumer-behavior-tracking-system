<?php

return [
    'users' => 'Users',
    'roles' => 'Roles',
];
