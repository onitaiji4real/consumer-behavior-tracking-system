<?php

return [
    'flash_sale' => 'Flash Sale',
    'flash_sales' => 'Flash Sales',
    'table' => [
        'campaign_name' => 'Campaign Name',
    ],
    'tabs' => [
        'group' => [
            'flash_sale_information' => 'Flash Sale Information',
        ],
        'products' => 'Products',
        'settings' => 'Settings',
    ],
    'form' => [
        'add_product' => 'Add Product',
        'flash_sale_product' => 'Flash Sale Product',
    ],
];
