<?php

return [
    'product' => 'Product',
    'end_date' => 'End Date',
    'price' => 'Price',
    'quantity' => 'Quantity',
    'campaign_name' => 'Campaign Name',

    // validation
    'products.*.product_id' => 'Product',
    'products.*.end_date' => 'End Date',
    'products.*.price' => 'Price',
    'products.*.qty' => 'Quantity',
];
