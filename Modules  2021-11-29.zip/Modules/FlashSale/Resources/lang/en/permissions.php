<?php

return [
    'index' => 'Index Flash Sale',
    'create' => 'Create Flash Sale',
    'edit' => 'Edit Flash Sale',
    'destroy' => 'Delete Flash Sale',
];
