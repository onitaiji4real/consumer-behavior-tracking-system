import FlashSale from './FlashSale';

new FlashSale();

window.admin.removeSubmitButtonOffsetOn(['#products']);
