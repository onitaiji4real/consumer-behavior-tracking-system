<?php

return [
    'attribute_value' => 'Attribute Value',
    'attribute_values' => 'Attribute Values',
];
