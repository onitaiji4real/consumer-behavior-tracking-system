<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    1 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    1 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);