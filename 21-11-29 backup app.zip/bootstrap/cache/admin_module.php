<?php return array (
  'providers' => 
  array (
    0 => 'Maatwebsite\\Sidebar\\SidebarServiceProvider',
    1 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    2 => 'Modules\\Admin\\Providers\\SidebarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Maatwebsite\\Sidebar\\SidebarServiceProvider',
    1 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    2 => 'Modules\\Admin\\Providers\\SidebarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);