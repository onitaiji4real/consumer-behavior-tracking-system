<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Page\\Providers\\PageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Page\\Providers\\PageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);