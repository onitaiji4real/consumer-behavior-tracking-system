<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Shipping\\Providers\\ShippingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Shipping\\Providers\\ShippingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);