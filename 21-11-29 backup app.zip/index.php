<?php

header('Location: public');
