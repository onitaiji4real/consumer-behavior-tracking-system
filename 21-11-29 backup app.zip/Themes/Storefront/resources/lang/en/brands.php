<?php

return [
    'brands' => 'Brands',
    'no_brand_found' => 'Oops! No brand found.',
];
