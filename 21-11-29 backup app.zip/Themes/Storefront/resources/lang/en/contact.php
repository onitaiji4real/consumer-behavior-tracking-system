<?php

return [
    'contact' => 'Contact',
    'leave_a_message' => 'Leave a Message',
    'send_message' => 'SEND MESSAGE',
];
