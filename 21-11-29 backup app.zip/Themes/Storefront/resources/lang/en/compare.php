<?php

return [
    'compare' => 'Compare',
    'no_product' => 'No product in the compare list.',
    'product_overview' => 'Product Overview',
    'description' => 'Description',
    'rating' => 'Rating',
    'availability' => 'Availability',
    'in_stock' => 'In Stock',
    'out_of_stock' => 'Out of Stock',
    'price' => 'Price',
    'actions' => 'Actions',
    'add_to_cart' => 'Add to cart',
];
