<?php

return [
    'default' => 'Default',
    'slider_with_banners' => 'Slider With Banners',
];
