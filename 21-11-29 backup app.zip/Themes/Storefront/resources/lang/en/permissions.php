<?php

return [
    'storefront' => [
        'edit' => 'Edit Storefront Settings',
    ],
];
