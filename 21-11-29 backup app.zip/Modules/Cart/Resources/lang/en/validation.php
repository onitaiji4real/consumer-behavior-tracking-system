<?php

return [
    'this_field_is_required' => 'This field is required.',
    'the_selected_option_is_invalid' => 'The selected option is invalid.',
];
