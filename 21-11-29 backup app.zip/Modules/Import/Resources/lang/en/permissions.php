<?php

return [
    'index' => 'Index Import',
    'create' => 'Create Import',
];
