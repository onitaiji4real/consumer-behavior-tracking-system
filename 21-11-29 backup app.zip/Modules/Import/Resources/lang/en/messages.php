<?php

return [
    'the_importer_has_been_run_successfully' => 'The importer has been run successfully.',
    'there_was_an_error_on_rows' => 'There was an error on rows (:rows).',
];
